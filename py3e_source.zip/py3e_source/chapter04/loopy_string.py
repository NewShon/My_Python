# Loopy String
# Demonstrates the for loop with a string

word = input("Enter a word: ")

print("\nHere's each letter in your word:")
for letter in word:
    print(letter)

input("\n\nPress the enter key to exit.")
