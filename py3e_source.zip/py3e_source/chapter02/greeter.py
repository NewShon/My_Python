# Greeter
# Demonstrates the use of a variable

name = "Larry"

print(name)

print("Hi,", name)

input("\n\nPress the enter key to exit.")
